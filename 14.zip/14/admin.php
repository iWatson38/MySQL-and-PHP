<?
    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $s = 'SELECT * FROM `users`';
    $result = $bd->query($s);

    echo 'Список пользователей: <br>';
    while ($row = $result->fetch_assoc()) {
?>
<form method="POST" action="set.php">
    <? 
    echo $row['login']
    ?>
    <input type="hidden" name="user" value='<? echo $row['login'] ?>'>
    <input type="number" name="balance" value='<? $row['balance'] ?>' size=5>
    <input type="submit" value="Установить новое значение">
</form>
<?
    }
?>