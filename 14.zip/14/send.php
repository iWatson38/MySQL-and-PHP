<?
    session_start();
    if (!isset($_SESSION['username'])) {
        exit ("Необходимо выполнить <a href='index.html'>вход</a>");
    }

    $sender = $_SESSION['username'];
    $receiver = $_POST['receiver'];
    $sum = floatval($_POST['sum']);

    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $s = "SELECT `balance` FROM `users` WHERE `login` = '$sender'";
    $Balance = $bd->query($s);
    if ($Balance >= $sum) {
        $bd->query("UPDATE `users` SET `balance` = `balance`-$sum WHERE `login` = '$sender'");
        $bd->query("UPDATE `users` SET `balance` = `balance`+$sum WHERE `login` = '$receiver'");
        ?>
        <a href="main.php">Главное меню</a>
        <?
    } else {
        echo "На вашем счете недостаточно средств!";
        ?>
        <a href="send_form.php">Назад</a>
        <?
    }
?>
