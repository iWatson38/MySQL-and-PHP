<?
    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $newbalance = $_POST['balance'];
    $user = $_POST['user'];

    $s = "UPDATE `users` SET `balance` = '$newbalance' WHERE `login` = '$user'";
    $bd->query($s);
?>
<a href="admin.php">Продолжить</a>