<?
    session_start();
    if (!isset($_SESSION['username'])) {
        exit ("Необходимо выполнить <a href='index.html'>вход</a>");
    }

    echo "Здравствуйте, ".$_SESSION['username'].'<br>';

    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $Username = $_SESSION['username'];
    $s = "SELECT * FROM `users` WHERE `login` = '$Username'";
    $result = $bd->query($s);
    $record = $result->fetch_assoc();
    $balance = $record['balance'];
    echo "На вашем счету: ".$balance." условных едениц.<br>";
?>
<a href="send_form.php">Перевод едениц другому пользователю</a><br>
<a href="password_change.php">Смена пороля</a><br>
<a href="delete.php">Удалить профиль</a><br>
<a href="exit.php">Выход</a>