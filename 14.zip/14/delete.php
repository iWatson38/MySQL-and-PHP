<?
    session_start();
    if (!isset($_SESSION['username'])) {
        exit ("Необходимо выполнить <a href='index.html'>вход</a>");
    }
?>
Для удаления профиля введите пароль:<br>
<form method="POST" action=""><br>
    <input required type="password" name="password"><br>
    <input type="submit" value="Удалить профиль">
</form><br>
<?
    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $Password = $_POST['password'];
    $user = $_SESSION['username'];
    $s = "SELECT `password` FROM `users` WHERE `login` = '$user'";
    $result = $bd->query($s);
    $record = $result->fetch_assoc();
    $P = $record['password'];

    if ($Password != $P && $Password != "") {
        echo "Неверный пароль!<br>";
    } else if ($Password != "") {
        $bd->query("DELETE FROM `users` WHERE `login` = '$user'");
        session_destroy();
        ?>
        <a href="index.html">Вход</a>
        <?
    }
?>