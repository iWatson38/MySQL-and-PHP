<?
    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $login = $_POST['login'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];

    if ($password == $password2) {
        $bd->query("INSERT INTO `users` (`login`, `password`) VALUES ('$login', '$password')");
        ?>
        Регистрация прошла успешно!<br>
        <a href="index.html">Вход</a>
        <?
    } else {
        echo "Поля".'"'."Пароль".'"'." и ".'"'."Подтвержение пароля".'"'." должны совпадать!";
        ?>
        <a href="reg_form.html">Регистрация</a>
        <?
    }
?>