<?
    session_start();
    session_destroy();
?>
<a href="main.php">Глвное меню</a>