<?
    session_start();
    if (!isset($_SESSION['username'])) {
        exit ("Необходимо выполнить <a href='index.html'>вход</a>");
    }
?>
Смена пароля<br>
<form method="POST" action=""><br>
    Старый пароль: <input required type="password" name="password"><br>
    Новый пароль: <input required type="password" name="password1" pattern="^[A-Za-z0-9]{6}" title="Пароль должен содержать: 6 и более символов, цифры и латинские буквы!"><br>
    Подтверждение нового пароля: <input required type="password" name="password2" pattern="^[A-Za-z0-9]{6}" title="Пароль должен содержать: 6 и более символов, цифры и латинские буквы!"><br>
    <input type="submit" value="Сменить пароль">
</form><br>
<?
    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $Password = $_POST['password'];
    $Password1 = $_POST['password1'];
    $Password2 = $_POST['password2'];
    $user = $_SESSION['username'];
    $s = "SELECT `password` FROM `users` WHERE `login` = '$user'";
    $result = $bd->query($s);
    $record = $result->fetch_assoc();
    $P = $record['password'];

    if ($Password != $P && $Password != "") {
        echo "Неверный пароль!<br>";
    } else if ($Password1 != $Password2) {
        echo "Поля".'"'."Новый пароль".'"'." и ".'"'."Подтвержение нового пароля".'"'." должны совпадать!<br>";
    } else if ($Password != "") {
        $bd->query("UPDATE `users` SET `password` = '' WHERE `login` = '$user'");
        $bd->query("UPDATE `users` SET `password` = '$Password2' WHERE `login` = '$user'");
        echo "Пароль успешно изменён!<br>";
    }
?>
<a href="main.php">Глвное меню</a>