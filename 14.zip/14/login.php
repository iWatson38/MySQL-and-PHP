<?
    $bd = new mysqli ('localhost', 'root', '', 'mybd');
    $bd->set_charset("cp1251");
    $bd->query('SET NAMES utf8');

    $Login = $_POST['login'];
    $Password = $_POST['password'];
    $s = "SELECT `login`, `password` FROM `users` WHERE `login` = '$Login'";
    $result = $bd->query($s);

    if ($result->num_rows > 0) {
        $record = $result->fetch_assoc();
        if ($record['password'] != $Password) {
            exit ('Пароль указан неверно!');
        }
        session_start ();
        $_SESSION['username'] = $Login;
        echo "Вход выполнен успешно!<br>";
        echo "<a href='main.php'>Продолжить</a>";
    } else {
        exit ('Пользователь с указанным именем пользователя не зарегестрирован');
    }
?>