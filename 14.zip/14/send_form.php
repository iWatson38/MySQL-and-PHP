<?
    session_start();
    if (!isset($_SESSION['username'])) {
        exit ("Необходимо выполнить <a hraf='index.html'>вход</a>");
    }
?>
Перевод средств<br>
<form method="POST" action="send.php"><br>
    Получатель: <input type="text" name="receiver"><br>
    Сумма: <input type="number" name="sum" min="1" value="1"><br>
    <input type="submit" value="Выполнить перевод">
</form><br>
<a href="main.php">Глвное меню</a>